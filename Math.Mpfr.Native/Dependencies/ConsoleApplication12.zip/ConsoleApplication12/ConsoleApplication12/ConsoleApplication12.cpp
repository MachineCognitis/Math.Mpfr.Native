// ConsoleApplication12.cpp : Defines the entry point for the console application.
//

#include "stdafx.h"
#include "gmp.h"
#include "mpfr.h"


int main()
{
	// Example of call into MPFR.

	mpfr_t op, rop;
	mpfr_init2(op, 64);
	mpfr_init2(rop, 64);
	mpfr_sin(rop, op, MPFR_RNDN);

	mpfr_clear(op);
	mpfr_clear(rop);

    return 0;
}

